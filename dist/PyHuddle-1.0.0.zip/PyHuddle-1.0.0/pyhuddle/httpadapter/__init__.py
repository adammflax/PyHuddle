__author__ = 'adam.flax'

__all__ = ["adapter", "caselessdictionary", "adapterurllib"]
